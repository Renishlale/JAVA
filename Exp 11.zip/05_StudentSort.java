import java.util.*;

public class StudentSort {
    public static void main(String[] args) {
        ArrayList<String> students = new ArrayList<>();

        students.add("Rahul");
        students.add("Amit");
        students.add("Sneha");
        students.add("Priya");
        students.add("Neha");

        Collections.sort(students, (a, b) -> a.compareTo(b));

        System.out.println("Sorted Student Names:");
        for (String name : students) {
            System.out.println(name);
        }
    }
}
