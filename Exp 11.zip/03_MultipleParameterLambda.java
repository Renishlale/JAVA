interface Addition {
    int add(int a, int b);
}

public class MultipleParameterLambda {
    public static void main(String[] args) {
        Addition a = (x, y) -> x + y;
        System.out.println("Sum = " + a.add(10, 20));
    }
}
