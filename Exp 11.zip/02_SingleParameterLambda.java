interface Square {
    int calculate(int n);
}

public class SingleParameterLambda {
    public static void main(String[] args) {
        Square s = n -> n * n;
        System.out.println("Square = " + s.calculate(5));
    }
}
