interface Calculator {
    double calculate(double a, double b);
}

public class LambdaCalculator {
    public static void main(String[] args) {
        Calculator add = (a, b) -> a + b;
        Calculator sub = (a, b) -> a - b;
        Calculator mul = (a, b) -> a * b;
        Calculator div = (a, b) -> a / b;

        double a = 20;
        double b = 5;

        System.out.println("Addition = " + add.calculate(a, b));
        System.out.println("Subtraction = " + sub.calculate(a, b));
        System.out.println("Multiplication = " + mul.calculate(a, b));
        System.out.println("Division = " + div.calculate(a, b));
    }
}
