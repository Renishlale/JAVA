class Wrapper3 {
    public static void main(String[] args){
        String str="25";
        Integer num=Integer.valueOf(str);
        if(num%2==0) System.out.println(num+" is Even");
        else System.out.println(num+" is Odd");
    }
}