class Wrapper1 {
    public static void main(String[] args) {
        String str="123";
        Integer obj=Integer.valueOf(str);
        int num=obj.intValue();
        System.out.println("Original String: "+str);
        System.out.println("Wrapper Object: "+obj);
        System.out.println("Primitive Value: "+num);
    }
}