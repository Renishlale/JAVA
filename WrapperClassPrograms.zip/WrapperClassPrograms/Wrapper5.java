class Wrapper5 {
    public static void main(String[] args){
        Integer n1=Integer.valueOf("20"), n2=Integer.valueOf("5");
        char op='*';
        switch(op){
            case '+': System.out.println("Result = "+(n1+n2)); break;
            case '-': System.out.println("Result = "+(n1-n2)); break;
            case '*': System.out.println("Result = "+(n1*n2)); break;
            case '/': System.out.println("Result = "+(n1/n2)); break;
            default: System.out.println("Invalid Operation");
        }
    }
}