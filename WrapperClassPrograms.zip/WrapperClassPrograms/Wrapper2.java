class Wrapper2 {
    public static void main(String[] args){
        String a="50", b="70";
        Integer n1=Integer.valueOf(a), n2=Integer.valueOf(b);
        System.out.println("Sum = "+(n1+n2));
    }
}