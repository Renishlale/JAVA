class Wrapper4 {
    public static void main(String[] args){
        Integer n1=Integer.valueOf("45"), n2=Integer.valueOf("89"), n3=Integer.valueOf("67");
        int largest=n1;
        if(n2>largest) largest=n2;
        if(n3>largest) largest=n3;
        System.out.println("Largest Number = "+largest);
    }
}