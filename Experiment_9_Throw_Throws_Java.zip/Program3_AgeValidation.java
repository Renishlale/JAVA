import java.util.Scanner;

public class Program3_AgeValidation {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter age: ");
        int age = sc.nextInt();

        try {
            if (age < 18) {
                throw new Exception("Age is less than 18. Not eligible.");
            }
            System.out.println("Eligible: Age is 18 or above.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        sc.close();
    }
}
