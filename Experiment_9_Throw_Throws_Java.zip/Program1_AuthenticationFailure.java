import java.util.Scanner;

public class Program1_AuthenticationFailure {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        try {
            if (!password.equals("admin123")) {
                throw new Exception("Authentication Failure!");
            }
            System.out.println("Authentication Successful!");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        sc.close();
    }
}
