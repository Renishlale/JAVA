Experiment No. 9 - Implementation of throw and throws in Java

Programs included:
1. Authentication Failure using throw
2. Even Number validation using throw
3. Age validation using throw
4. throws keyword with ArithmeticException
5. User-defined exception for student marks

Compile example:
javac Program1_AuthenticationFailure.java

Run example:
java Program1_AuthenticationFailure

All programs are standalone Java files.
