import java.util.Scanner;

public class Program2_EvenNumber {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = sc.nextInt();

        try {
            if (number % 2 != 0) {
                throw new Exception("Number is not even!");
            }
            System.out.println("The number is even.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        sc.close();
    }
}
