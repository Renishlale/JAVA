import java.util.Scanner;
interface FY{ void getFY(); }
interface SY{ void getSY(); }
public class MultipleInheritance implements FY,SY{
 int fyRoll,syRoll; String fyName,syName,fyResult,syResult; Scanner sc=new Scanner(System.in);
 public void getFY(){ System.out.print("FY Roll: "); fyRoll=sc.nextInt(); sc.nextLine(); System.out.print("FY Name: "); fyName=sc.nextLine(); System.out.print("FY Result: "); fyResult=sc.nextLine();}
 public void getSY(){ System.out.print("SY Roll: "); syRoll=sc.nextInt(); sc.nextLine(); System.out.print("SY Name: "); syName=sc.nextLine(); System.out.print("SY Result: "); syResult=sc.nextLine();}
 void display(){ System.out.println("FY: "+fyRoll+" "+fyName+" "+fyResult); System.out.println("SY: "+syRoll+" "+syName+" "+syResult);}
 public static void main(String[] args){ MultipleInheritance s=new MultipleInheritance(); s.getFY(); s.getSY(); s.display();}
}