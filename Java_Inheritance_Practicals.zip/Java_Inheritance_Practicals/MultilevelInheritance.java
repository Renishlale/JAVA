import java.util.Scanner;
class Book { String author,title,publisher; }
class BookInfo extends Book { int price,stock; }
public class MultilevelInheritance extends BookInfo {
    int copies; Scanner sc=new Scanner(System.in);
    void accept(){
        System.out.print("Author: "); author=sc.nextLine();
        System.out.print("Title: "); title=sc.nextLine();
        System.out.print("Publisher: "); publisher=sc.nextLine();
        System.out.print("Price: "); price=sc.nextInt();
        System.out.print("Stock: "); stock=sc.nextInt();
        System.out.print("Copies Sold: "); copies=sc.nextInt();
    }
    void RevenueGenerated(){ System.out.println("Revenue = "+(price*copies));}
    void AllShow(){
        System.out.println(author);System.out.println(title);System.out.println(publisher);
        System.out.println(price);System.out.println(stock);System.out.println(copies);
    }
    public static void main(String[] args){
        MultilevelInheritance b=new MultilevelInheritance();
        b.accept(); b.AllShow(); b.RevenueGenerated();
    }
}