class Book {
    String author, title, publisher;
}
class BookInfo extends Book {
    int price, stock;
    void show() {
        System.out.println(author + " " + title + " " + publisher);
        System.out.println(price + " " + stock);
        System.out.println();
    }
}
public class SingleInheritance {
    public static void main(String args[]) {
        BookInfo b1=new BookInfo();
        b1.author="James"; b1.title="Java"; b1.publisher="ABC"; b1.price=500; b1.stock=20;
        BookInfo b2=new BookInfo();
        b2.author="Dennis"; b2.title="C"; b2.publisher="XYZ"; b2.price=400; b2.stock=15;
        BookInfo b3=new BookInfo();
        b3.author="Bjarne"; b3.title="C++"; b3.publisher="PQR"; b3.price=600; b3.stock=10;
        b1.show(); b2.show(); b3.show();
    }
}