EXPERIMENT 8 - EXCEPTION HANDLING

Compile and run each program separately:
javac Q1_DivisionException.java
java Q1_DivisionException

javac Q2_ArrayException.java
java Q2_ArrayException

javac Q3_NumberFormatException.java
java Q3_NumberFormatException

javac Q4_MultipleCatch.java
java Q4_MultipleCatch

javac Q5_NestedTryCatch.java
java Q5_NestedTryCatch
