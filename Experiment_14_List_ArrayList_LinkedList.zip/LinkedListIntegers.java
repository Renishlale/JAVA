import java.util.LinkedList;

public class LinkedListIntegers {
    public static void main(String[] args) {
        LinkedList<Integer> numbers = new LinkedList<>();
        numbers.add(10);
        numbers.add(20);
        numbers.add(30);
        numbers.addFirst(5);
        System.out.println("Original list: " + numbers);
        numbers.remove(Integer.valueOf(20));
        System.out.println("After deleting 20: " + numbers);
        System.out.println("Traversing list:");
        for (int number : numbers) {
            System.out.println(number);
        }
    }
}
