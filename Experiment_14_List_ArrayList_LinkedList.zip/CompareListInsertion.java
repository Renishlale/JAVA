import java.util.ArrayList;
import java.util.LinkedList;

public class CompareListInsertion {
    public static void main(String[] args) {
        int count = 100000;
        ArrayList<Integer> arrayList = new ArrayList<>();
        LinkedList<Integer> linkedList = new LinkedList<>();

        long start = System.nanoTime();
        for (int i = 0; i < count; i++) {
            arrayList.add(0, i);
        }
        long arrayTime = System.nanoTime() - start;

        start = System.nanoTime();
        for (int i = 0; i < count; i++) {
            linkedList.addFirst(i);
        }
        long linkedTime = System.nanoTime() - start;

        System.out.println("Elements inserted: " + count);
        System.out.println("ArrayList front-insertion time: " + arrayTime / 1_000_000.0 + " ms");
        System.out.println("LinkedList front-insertion time: " + linkedTime / 1_000_000.0 + " ms");
    }
}
