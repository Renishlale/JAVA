import java.util.ArrayList;
import java.util.List;

public class ListOperations {
    public static void main(String[] args) {
        List<String> items = new ArrayList<>();
        items.add("Apple");
        items.add("Banana");
        items.add("Mango");
        System.out.println("List: " + items);
        items.remove("Banana");
        System.out.println("After deletion: " + items);
        System.out.println("Contains Mango: " + items.contains("Mango"));
        System.out.println("Elements: " + items);
    }
}
