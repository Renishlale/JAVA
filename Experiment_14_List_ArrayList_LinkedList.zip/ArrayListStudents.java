import java.util.ArrayList;

public class ArrayListStudents {
    public static void main(String[] args) {
        ArrayList<String> students = new ArrayList<>();
        students.add("Aarav");
        students.add("Priya");
        students.add("Rohan");
        students.add("Sneha");
        System.out.println("Student names: " + students);
    }
}
