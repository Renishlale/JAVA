class Odd extends Thread {
    public void run() {
        for (int i = 1; i <= 20; i += 2)
            System.out.println("Odd: " + i);
    }
}

class Even extends Thread {
    public void run() {
        for (int i = 2; i <= 20; i += 2)
            System.out.println("Even: " + i);
    }
}

public class Thread2 {
    public static void main(String[] args) {
        Odd o = new Odd();
        Even e = new Even();
        o.start();
        e.start();
    }
}
