class A extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++)
            System.out.println(i);
    }
}

public class Thread6 {
    public static void main(String[] args) {
        A a = new A();
        a.start();

        try {
            a.join();
        } catch (Exception e) {
        }

        System.out.println("Main thread finished");
    }
}
