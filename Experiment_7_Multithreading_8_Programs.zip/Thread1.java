class A extends Thread {
    public void run() {
        for (int i = 1; i <= 10; i++) {
            System.out.println("A: " + i);
            if (i == 2)
                Thread.yield();
        }
    }
}

class B extends Thread {
    public void run() {
        for (int i = 10; i >= 1; i--) {
            System.out.println("B: " + i);
        }
    }
}

public class Thread1 {
    public static void main(String[] args) {
        A a = new A();
        B b = new B();
        a.start();
        b.start();
    }
}
