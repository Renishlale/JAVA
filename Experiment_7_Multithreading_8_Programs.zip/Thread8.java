class Sum extends Thread {
    int[] a;

    Sum(int[] a) {
        this.a = a;
    }

    public void run() {
        int sum = 0;

        for (int i = 0; i < a.length; i++)
            sum = sum + a[i];

        System.out.println("Sum = " + sum);
    }
}

public class Thread8 {
    public static void main(String[] args) {
        int[] a = {1, 2, 3, 4, 5};
        int[] b = {10, 20, 30, 40, 50};

        Sum s1 = new Sum(a);
        Sum s2 = new Sum(b);

        s1.start();
        s2.start();
    }
}
