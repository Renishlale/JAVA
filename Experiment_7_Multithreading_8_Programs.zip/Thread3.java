class A extends Thread {
    public void run() {
        for (int i = 10; i <= 20; i++) {
            System.out.println("A: " + i);
            if (i == 11) {
                try {
                    Thread.sleep(1000);
                } catch (Exception e) {
                }
            }
        }
    }
}

class B extends Thread {
    public void run() {
        for (int i = 20; i >= 1; i--) {
            System.out.println("B: " + i);
        }
    }
}

public class Thread3 {
    public static void main(String[] args) {
        A a = new A();
        B b = new B();
        a.start();
        b.start();
    }
}
