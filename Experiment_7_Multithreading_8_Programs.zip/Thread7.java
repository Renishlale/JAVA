class A extends Thread {
    public void run() {
        System.out.println("Thread A: " + getPriority());
    }
}

class B extends Thread {
    public void run() {
        System.out.println("Thread B: " + getPriority());
    }
}

public class Thread7 {
    public static void main(String[] args) {
        A a = new A();
        B b = new B();
        a.setPriority(1);
        b.setPriority(10);
        a.start();
        b.start();
    }
}
