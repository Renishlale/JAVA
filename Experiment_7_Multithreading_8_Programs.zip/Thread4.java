class Number extends Thread {
    public void run() {
        for (int i = 1; i <= 5; i++)
            System.out.println("Number: " + i);
    }
}

class Alphabet extends Thread {
    public void run() {
        for (char c = 'A'; c <= 'E'; c++)
            System.out.println("Alphabet: " + c);
    }
}

class Special extends Thread {
    public void run() {
        for (int i = 0; i < 5; i++)
            System.out.println("Special: " + "@#$%&".charAt(i));
    }
}

public class Thread4 {
    public static void main(String[] args) {
        Number n = new Number();
        Alphabet a = new Alphabet();
        Special s = new Special();
        n.start();
        a.start();
        s.start();
    }
}
