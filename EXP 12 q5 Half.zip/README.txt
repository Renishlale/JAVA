FUNCTIONAL INTERFACE JAVA PROGRAMS
=================================

This folder contains the 5 programs required by Experiment No. 12.

Files:
1. UserDefinedFunctionalInterface.java
2. ConsumerDemo.java
3. PredicateDemo.java
4. FunctionDemo.java
5. SupplierDemo.java

REQUIREMENT
-----------
Java 8 or later.

HOW TO RUN
----------

1. Extract the ZIP file.
2. Open Command Prompt/Terminal in the extracted folder.
3. Compile all programs:

   javac *.java

4. Run any program:

   java UserDefinedFunctionalInterface
   java ConsumerDemo
   java PredicateDemo
   java FunctionDemo
   java SupplierDemo

You can also compile and run one program at a time.

EXPECTED EXAMPLE OUTPUT
-----------------------
UserDefinedFunctionalInterface:
Hello, Student!

ConsumerDemo:
Name: Rahul

PredicateDemo:
Is 10 even? true

FunctionDemo:
Square of 5: 25

SupplierDemo:
Hello from Supplier!
