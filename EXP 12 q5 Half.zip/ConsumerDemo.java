import java.util.function.Consumer;

public class ConsumerDemo {
    public static void main(String[] args) {
        Consumer<String> display = name -> System.out.println("Name: " + name);

        display.accept("Rahul");
    }
}
