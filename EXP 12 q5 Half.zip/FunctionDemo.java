import java.util.function.Function;

public class FunctionDemo {
    public static void main(String[] args) {
        Function<Integer, Integer> square = number -> number * number;

        System.out.println("Square of 5: " + square.apply(5));
    }
}
