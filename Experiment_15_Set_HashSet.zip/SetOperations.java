import java.util.HashSet;
import java.util.Set;

public class SetOperations {
    public static void main(String[] args) {
        Set<String> fruits = new HashSet<>();
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Mango");
        System.out.println("Set: " + fruits);
        fruits.remove("Banana");
        System.out.println("After deletion: " + fruits);
        System.out.println("Contains Mango: " + fruits.contains("Mango"));
        System.out.println("Elements: " + fruits);
    }
}
