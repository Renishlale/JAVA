import java.util.HashSet;

public class EmployeeNames {
    public static void main(String[] args) {
        HashSet<String> employees = new HashSet<>();
        employees.add("Amit");
        employees.add("Neha");
        employees.add("Rahul");
        employees.add("Priya");
        System.out.println("Employee names: " + employees);
    }
}
