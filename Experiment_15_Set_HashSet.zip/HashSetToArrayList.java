import java.util.ArrayList;
import java.util.HashSet;

public class HashSetToArrayList {
    public static void main(String[] args) {
        HashSet<String> fruits = new HashSet<>();
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Mango");
        fruits.add("Orange");
        ArrayList<String> fruitList = new ArrayList<>(fruits);
        System.out.println("HashSet: " + fruits);
        System.out.println("ArrayList: " + fruitList);
    }
}
