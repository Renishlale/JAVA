```java
class Area
{
    double area(double radius)
    {
        return 3.14 * radius * radius;
    }

    int area(int side)
    {
        return side * side;
    }

    int area(int length, int breadth)
    {
        return length * breadth;
    }

    public static void main(String[] args)
    {
        Area a = new Area();

        double circleArea = a.area(5.0);
        int squareArea = a.area(4);
        int rectangleArea = a.area(6, 4);

        System.out.println("Area of Circle = " + circleArea);
        System.out.println("Area of Square = " + squareArea);
        System.out.println("Area of Rectangle = " + rectangleArea);
    }
}
```
