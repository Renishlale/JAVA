import org.joda.time.LocalDate;

public class JodaDateAdjustment {
    public static void main(String[] args) {
        LocalDate date = new LocalDate(2026, 10, 15);
        System.out.println("Original date: " + date);
        System.out.println("After 10 days: " + date.plusDays(10));
        System.out.println("Before 2 months: " + date.minusMonths(2));
        System.out.println("After 1 year: " + date.plusYears(1));
        System.out.println("Before 1 year: " + date.minusYears(1));
    }
}
