import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CurrentJavaTime {
    public static void main(String[] args) {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        System.out.println("Current date and time: " + now.format(format));
    }
}
