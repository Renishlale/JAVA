import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

public class CurrentJodaTime {
    public static void main(String[] args) {
        DateTime now = DateTime.now();
        System.out.println("Current date and time: " +
                now.toString(DateTimeFormat.forPattern("dd-MM-yyyy HH:mm:ss")));
    }
}
