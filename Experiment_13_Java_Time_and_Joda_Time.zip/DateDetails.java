import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.Locale;

public class DateDetails {
    public static void main(String[] args) {
        LocalDate date = LocalDate.of(2026, 10, 15);
        System.out.println("Date: " + date);
        System.out.println("Day of week: " + date.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH));
        System.out.println("Month: " + date.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH));
        System.out.println("Year: " + date.getYear());
    }
}
