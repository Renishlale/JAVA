import java.time.LocalDate;
import java.time.Period;

public class DateDifference {
    public static void main(String[] args) {
        LocalDate date1 = LocalDate.of(2026, 1, 10);
        LocalDate date2 = LocalDate.of(2026, 10, 15);
        Period difference = Period.between(date1, date2);
        System.out.println("Date 1: " + date1);
        System.out.println("Date 2: " + date2);
        System.out.println("Difference: " + difference.getYears() + " years, " +
                difference.getMonths() + " months, " + difference.getDays() + " days");
        System.out.println("Total days: " + java.time.temporal.ChronoUnit.DAYS.between(date1, date2));
    }
}
