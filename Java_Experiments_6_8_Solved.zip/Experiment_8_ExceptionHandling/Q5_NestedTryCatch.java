public class Q5_NestedTryCatch {
    public static void main(String[] args) {
        try {
            System.out.println("Outer try block started.");

            try {
                System.out.println("Inner try block started.");
                int result = 10 / 0;
                System.out.println("Result: " + result);
            } catch (ArithmeticException e) {
                System.out.println("Inner catch: Cannot divide by zero.");
            }

            try {
                int[] numbers = {1, 2, 3};
                System.out.println(numbers[5]);
            } catch (ArithmeticException e) {
                System.out.println("Inner catch: Arithmetic error.");
            }

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Outer catch: Array index is out of bounds.");
        }

        System.out.println("Program completed.");
    }
}
