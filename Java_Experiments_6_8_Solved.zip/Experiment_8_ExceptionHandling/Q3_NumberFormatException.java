import java.util.Scanner;

public class Q3_NumberFormatException {
    public static int convertToInt(String value) {
        return Integer.parseInt(value);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number: ");
        String input = sc.nextLine();

        try {
            int number = convertToInt(input);
            System.out.println("Converted integer: " + number);
        } catch (NumberFormatException e) {
            System.out.println("Error: '" + input + "' is not a valid integer.");
        } finally {
            sc.close();
        }
    }
}
