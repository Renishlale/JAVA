JAVA EXPERIMENTS 6 AND 8
=========================

Requirements:
- Java JDK 8 or later
- VS Code, IntelliJ IDEA, Eclipse, or Command Prompt

EXPERIMENT 6 - USER-DEFINED PACKAGE
------------------------------------
Folder: Experiment_6_UserDefinedPackage

Compile from inside the Experiment_6_UserDefinedPackage folder:
    javac bank/Account.java Main.java

Run:
    java Main

EXPERIMENT 6 - EMPLOYEE EXPERIENCE CALCULATOR
----------------------------------------------
Folder: Experiment_6_EmployeeExperience

Compile:
    javac EmployeeExperienceCalculator.java

Run:
    java EmployeeExperienceCalculator

Enter the joining date in:
    dd-MM-yyyy

EXPERIMENT 8 - EXCEPTION HANDLING
---------------------------------
Folder: Experiment_8_ExceptionHandling

Question 1:
    javac Q1_DivisionException.java
    java Q1_DivisionException

Question 2:
    javac Q2_ArrayException.java
    java Q2_ArrayException

Question 3:
    javac Q3_NumberFormatException.java
    java Q3_NumberFormatException

Question 4:
    javac Q4_MultipleCatch.java
    java Q4_MultipleCatch

Question 5:
    javac Q5_NestedTryCatch.java
    java Q5_NestedTryCatch

VS CODE:
1. Extract the ZIP.
2. Open the extracted folder in VS Code.
3. Open the required .java file.
4. Make sure the Java Extension Pack/JDK is installed.
5. Run the file using the Run button, or use the terminal commands in this README.

NOTE:
The Employee Experience Calculator uses LocalDate.now(), so the calculated experience
automatically uses the date on which the program is executed.
