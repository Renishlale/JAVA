JAVA EXP 6

Question 1: User-defined package
Folder: Question1_UsefulPackage
Compile:
javac useful/useme.java
javac Test.java
Run:
java Test

Question 2: Built-in package
Folder: Question2_BuiltInPackage
Compile:
javac EmployeeExperience.java
Run:
java EmployeeExperience

Question 3: User-defined banking package
Folder: Question3_BankingApp
Compile:
javac bank/account.java
javac BankMain.java
Run:
java BankMain
