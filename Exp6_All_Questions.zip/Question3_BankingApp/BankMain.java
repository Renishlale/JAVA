import bank.account;

public class BankMain {
    public static void main(String[] args) {
        account account1 = new account("1001", "Renish", 10000);
        account account2 = new account("1002", "Rahul", 15000);

        System.out.println("Account 1");
        account1.deposit(5000);
        account1.withdraw(2000);
        account1.checkBalance();

        System.out.println();

        System.out.println("Account 2");
        account2.deposit(3000);
        account2.withdraw(4000);
        account2.checkBalance();
    }
}
