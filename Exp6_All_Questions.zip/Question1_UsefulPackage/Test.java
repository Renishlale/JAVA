import useful.useme;

public class Test {
    public static void main(String[] args) {
        useme obj = new useme();

        obj.area(5);
        obj.salary(25000, 5000);
        obj.percentage(450, 500);
    }
}
