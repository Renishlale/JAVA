package useful;

public class useme {
    public void area(double radius) {
        double result = 3.14 * radius * radius;
        System.out.println("Area of Circle = " + result);
    }

    public void salary(double basic, double allowance) {
        double result = basic + allowance;
        System.out.println("Salary = " + result);
    }

    public void percentage(double obtained, double total) {
        double result = (obtained / total) * 100;
        System.out.println("Percentage = " + result + "%");
    }
}
